<?php 

require_once ('model/model.php');

function fetchAllTransaction(){
	echo 'success';
	return showAllTransaction();

}
function fetchTransaction($username){
	//return showUsers($username);

}
